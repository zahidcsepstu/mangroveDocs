Creating Angular Project for Jenkins with Commands................

git clone https://github.com/devMangrove/jenkinsrnd.git
  git checkout -b main
  git branch angular
  git checkout -b angular
  git checkin
  git --help
  git add *
  git commit
  git add *
  git push
  git clone https://github.com/devMangrove/jenkinsrnd.git
  git checkout -b angular
  git checkout -d angular
  git clone https://github.com/devMangrove/jenkinsrnd.git
  git checkout angular
  git add .
  git status
  git add .
  git status
  git commit -m "initial commit with read_me"
  git status
  git push

