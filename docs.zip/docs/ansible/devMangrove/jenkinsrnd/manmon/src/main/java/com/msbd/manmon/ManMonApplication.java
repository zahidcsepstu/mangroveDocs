package com.msbd.manmon;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.Transactional;

//
//@Transactional(value = "em")
//@ComponentScan(basePackages = { "com.msbd.manmon" })

@SpringBootApplication
@EnableScheduling
@EnableAutoConfiguration
public class ManMonApplication {
 
//    private static final String PERSISTENCE_UNIT_NAME = "environment_status";
//    private static EntityManagerFactory factory;
    
    public static void main(String[] args) {
	
//	factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
//        EntityManager em = factory.createEntityManager();
	
        SpringApplication.run(ManMonApplication.class, args);
	
//	em.getTransaction().begin();
	
    }

}