
package com.msbd.manmon.frontendmodels;

public class NoiseValue {
    private double noiseValue;

    public NoiseValue() {
    }

    public double getNoiseValue() {
	return this.noiseValue;
    }

    public void setNoiseValue(double noiseValue) {
	this.noiseValue = noiseValue;
    }
    
    
}
