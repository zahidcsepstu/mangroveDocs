package com.msbd.manmon.repository;


//package com.msbd.manmon.services;
//
//import com.msbd.manmon.models.EnvironmentStatus;
//import java.util.Optional;
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.stereotype.Service;
//
//@Service
//public class ManMonCrudRepositoryImplements implements ManMonCrudRepository {
//
//    
//    
//}
