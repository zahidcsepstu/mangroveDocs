
package com.msbd.manmon.frontendmodels;

public class RelayInfo {
    
    private String replay01;
    private String replay02;
    private String replay03;
    private String replay04;

    public RelayInfo() {
    }

    public String getReplay01() {
        return replay01;
    }

    public void setReplay01(String replay01) {
        this.replay01 = replay01;
    }

    public String getReplay02() {
        return replay02;
    }

    public void setReplay02(String replay02) {
        this.replay02 = replay02;
    }

    public String getReplay03() {
        return replay03;
    }

    public void setReplay03(String replay03) {
        this.replay03 = replay03;
    }

    public String getReplay04() {
        return replay04;
    }

    public void setReplay04(String replay04) {
        this.replay04 = replay04;
    }

    
    
}
