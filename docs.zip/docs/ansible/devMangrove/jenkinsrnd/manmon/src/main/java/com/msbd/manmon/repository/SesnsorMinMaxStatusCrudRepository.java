
package com.msbd.manmon.repository;

import com.msbd.manmon.domainmodel.SensorMinMaxStatus;
import org.springframework.data.repository.CrudRepository;


public interface SesnsorMinMaxStatusCrudRepository extends CrudRepository<SensorMinMaxStatus, String>{
    
}
