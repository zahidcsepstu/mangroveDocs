angular.module('manmon', ["ngRoute", "ngMaterial", "ngMessages"]);
