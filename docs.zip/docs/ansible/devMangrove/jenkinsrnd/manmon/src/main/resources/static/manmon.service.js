(function(){
    //Your_Name
    'use strict'
    angular.module('manmon')
        .factory("manmonDataPreparationService", manmonDataPreparationService);
    /**@ngInject */
    function manmonDataPreparationService($scope, $state, $mdDialog, $stateParams){
        
    }
})();