
package com.msbd.manmon.domainmodel;

public class DatabseConstraints {
    private Integer maxDay;

    public DatabseConstraints() {
    }

    public Integer getMaxDay() {
	return maxDay;
    }

    public void setMaxDay(Integer maxDay) {
	this.maxDay = 30;
    }

}
