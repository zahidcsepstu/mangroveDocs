//
//package com.msbd.manmon.domainmodel.previous;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//@Entity
//@Table(name="last_relay_status_info")
//public class LastRelayStatusPrevious {
//    @Id
//    @Column
//    private String relayStatusId = "relayStatusId";
//    
//    @Column
//    private String relay1;
//    
//    @Column
//    private String relay2;
//    
//    @Column
//    private String relay3;
//    
//    @Column
//    private String relay4;
//
//    public LastRelayStatusPrevious() {
//
//    }
//
//    public String getRelay1() {
//        return relay1;
//    }
//
//    public void setRelay1(String relay1) {
//        this.relay1 = relay1;
//    }
//
//    public String getRelay2() {
//        return relay2;
//    }
//
//    public void setRelay2(String relay2) {
//        this.relay2 = relay2;
//    }
//
//    public String getRelay3() {
//        return relay3;
//    }
//
//    public void setRelay3(String relay3) {
//        this.relay3 = relay3;
//    }
//
//    public String getRelay4() {
//        return relay4;
//    }
//
//    public void setRelay4(String relay4) {
//        this.relay4 = relay4;
//    }
//}
